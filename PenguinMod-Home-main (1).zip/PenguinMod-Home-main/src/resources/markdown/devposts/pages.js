import DevPostShutdownIncident from "./shutdownincident.md?raw";

export default {
    "3-18-2025-shutdown-incident": DevPostShutdownIncident,
};