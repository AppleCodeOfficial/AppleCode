import GuidelinesUploading from "./uploading.md?raw";
import GuidelinesModeration from "./moderation.md?raw";

export default {
    "uploading": GuidelinesUploading,
    "moderation": GuidelinesModeration,
};