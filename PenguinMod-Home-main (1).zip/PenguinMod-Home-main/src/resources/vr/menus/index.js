import pageLoading from './loading.xml?raw';
import pageLogin from './login.xml?raw';
import pageHome from './home.xml?raw';

export default {
    pageLoading,
    pageLogin,
    pageHome,
};